{
	"name": "3columns",
	"displayName":"Row with 3 Columns",
	"version": 1,
	"icon": "12grid/3columns/3columns.png",
	"designStyleClass" : "rowDesign",
	"definition": "3columns/3columns.json",
	"contains": ["12grid.column"],
	"topContainer": true
}
