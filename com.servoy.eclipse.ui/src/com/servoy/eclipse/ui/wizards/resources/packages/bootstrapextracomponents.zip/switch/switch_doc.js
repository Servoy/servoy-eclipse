/**
 * Request the focus to this switch.
 *
 * @example %%prefix%%%%elementName%%.requestFocus();
 */
function requestFocus() {
}