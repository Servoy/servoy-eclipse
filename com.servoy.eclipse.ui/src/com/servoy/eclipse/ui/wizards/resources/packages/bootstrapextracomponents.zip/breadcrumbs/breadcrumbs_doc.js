/**
 * Sets all crumbs
 *
 * @param {Array<bootstrapextracomponents-breadcrumbs.crumb>} crumbs
 */
function setCrumbs(crumbs) {
}

/**
 * Adds a crumb at the end
 *
 * @param {bootstrapextracomponents-breadcrumbs.crumb} crumb
 */
function addCrumb(crumb) {
}

/**
 * Removes all crumbs after the given index
 *
 * @param {Number} index
 */
function removeCrumbsAfter(index) {
}

/**
 * Removes the last crumb
 */
function removeLastCrumb() {
}