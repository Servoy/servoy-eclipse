/**
* Set the focus to this button.
* 
* @example %%prefix%%%%elementName%%.requestFocus();
*/
function requestFocus() {}