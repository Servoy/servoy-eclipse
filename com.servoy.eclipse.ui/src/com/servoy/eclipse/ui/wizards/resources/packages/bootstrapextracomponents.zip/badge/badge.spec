{
	"name": "bootstrapextracomponents-badge",
	"displayName": "Badge",
	"categoryName": "Buttons & Text",
	"version": 1,
	"definition": "bootstrapextracomponents/badge/badge.js",
	"doc": "bootstrapextracomponents/badge/badge_doc.js",
	"icon": "bootstrapextracomponents/badge/icon.png",
	"libraries": [
		{"name":"badge.css", "version":"1.0.0", "url":"bootstrapextracomponents/badge/badge.css", "mimetype":"text/css"}
	],
	"keywords": ["tag"],
	"model":
	{
		"designsize" : {"type" :"dimension", "tags": {"serveronly": true, "scope": "private"}, "default" : {"width":100, "height":40}},
		"enabled" 						: {"type": "enabled", "blockingOn": false, "default": true, "for": ["onAction", "onDoubleClick", "onRightClick"] },
		"displayType" 					: {"type": "string", "default":"BUTTON", "values": ["BUTTON", "LABEL"], "tags": { "basic": true }},
		"text"							: {"type": "tagstring", "initialValue": "Badge", "tags": { "directEdit" : "true","basic": true  }},
		"badgeText"						: {"type": "tagstring", "initialValue": "0", "tags": { "basic": true }},
    	"imageStyleClass" 				: {"type": "styleclass"},
    	"styleClass"					: {"type": "styleclass"},
    	"visible"						: {"type": "visible" },
    	"toolTipText"					: {"type": "tagstring"}
	},
	"handlers": 
	{
		"onAction": 
		{
			"parameters": [
				{
					"name": "event",
					"type": "JSEvent"
				}
			]
		},
		"onDoubleClick": 
		{
			"parameters": [
				{
					"name": "event",
					"type": "JSEvent"
				}
			]
		},
		"onRightClick": 
		{
			"parameters": [
				{
					"name": "event",
					"type": "JSEvent"
				}
			]
		}
	}
}