{
	"name": "servoyextra-youtubevideoembedder",
	"displayName": "Embedded YouTube",
	"categoryName": "Media",
	"version": 1,
	"definition": "servoyextra/youtubevideoembedder/youtubevideoembedder.js",
	"doc": "servoyextra/youtubevideoembedder/youtubevideoembedder_doc.js",
	"libraries": [{ "name": "servoyextra-youtubeembed-css", "version": "1.0", "url": "servoyextra/youtubevideoembedder/youtubevideoembedder.css", "mimetype": "text/css" }],
    "icon": "servoyextra/youtubevideoembedder/youtubevideoembedder.png",
	"keywords": ["video", "google", "streaming"],
	"model": {
        "designsize" : {"type" :"dimension", "tags": {"serveronly": true, "scope": "private"}, "default" : {"width":426, "height":240}},
        "embeddedVideoURL": { "type": "string", "tags": { "doc" :"The youtube url can be provided as dataprovider (using dataProviderID property) or as text (using embeddedVideoURL property).", "basic": true } },
        "dataProviderID": { "type":"dataprovider", "tags": { "wizard": true, "scope": "design","doc" :"The youtube url can be provided as dataprovider (using dataProviderID property) or as text (using embeddedVideoURL property).", "basic": true }},
		"videoWidth": { "type": "int", "default": 426 },
		"videoHeight": { "type": "int", "default": 240 },
		"allowFullScreen": { "type": "boolean", "default": true },
		"autoPlay": { "type": "boolean", "default": false },
		"showControls": { "type": "boolean", "default": true },
		"modestBranding": { "type": "boolean", "default": false },
		"showRelatedVideosAtEnd": { "type": "boolean", "default": false },
		
        "styleClass": { "type" :"styleclass", "default": "youtubevideoembedder" }, 
        "tabSeq": { "type" :"tabseq", "tags": { "scope": "design" } }, 
        "visible": "visible"
        
	}
}