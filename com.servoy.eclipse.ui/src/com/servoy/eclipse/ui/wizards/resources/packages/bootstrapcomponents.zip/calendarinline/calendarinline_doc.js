
/**
 * Set the min date or max date that can be selected
 *  
* @param {Date} minDate
* @param {Date} maxDate
* 
*/
function setMinMaxDate(minDate, maxDate) {
}

/**
 *  Dates that should be disabled.
 *
 * @param {Array<Date>} dateArray
* 
*/
function disableDates(dateArray) {
}

/** 
* Days of the week that should be disabled. Values are 0 (Sunday) to 6 (Saturday).
* 
* @param {Array<Number>} dayArray
* 
*/
function disableDays(dayArray) {
};
