/**
 * Sets the progress, optionally setting the text of the bar
 *
 * @param {Number} value
 * @param {String} text
 */
function setProgress(value, text) {
}

/**
 * Do not call this method; this will be removed with Servoy 8.2
 * @param {Number} value
 * @param {String} text
 */
function updateProgressBar(value, text) {
}